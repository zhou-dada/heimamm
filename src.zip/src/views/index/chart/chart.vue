<template>
  <div>我是chart</div>
</template>

<script>
export default {

}
</script>

<style>

</style>