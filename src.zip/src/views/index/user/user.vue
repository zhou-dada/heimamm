<template>
  <div>我是user</div>
</template>

<script>
export default {

}
</script>

<style>

</style>